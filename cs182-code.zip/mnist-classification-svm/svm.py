#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# arguments define
import argparse
from cgi import test

# load torch
import torchvision

# other utilities
# import matplotlib.pyplot as plt
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix

import numpy as np

#%% Load the training data
def MNIST_DATASET_TRAIN(downloads, train_amount):
    # Load dataset
    training_data = torchvision.datasets.MNIST(
              root = './mnist/',
              train = True,
              download = downloads,
              transform=torchvision.transforms.ToTensor()
        #       transform = torchvision.transforms.Compose([
        # torchvision.transforms.ToTensor(),
        # torchvision.transforms.Normalize((0.1307,), (0.3081,))])
              
              )
    

    #Convert Training data to numpy
    train_data_raw = training_data.train_data.numpy()[:train_amount]
    train_label = training_data.train_labels.numpy()[:train_amount]
    
    # scalar = StandardScaler()
    # scalar.fit(train_data_raw)
    # train_data = scalar.transform(train_data_raw)

    train_data = train_data_raw/255.0
    #train_data = train_data_raw

    #Get part of the data
    train_data_new=[]
    train_label_new=[]
    cnt=0
    for i in range(len(train_label)):
        if train_label[i] in [0,1,2,3,4,5]:
            train_data_new.append(train_data[i])
            train_label_new.append(train_label[i])
            cnt+=1
    
    train_data_new=np.array(train_data_new)
    train_label_new=np.array(train_label_new)
    train_data_new.reshape(cnt,train_data.shape[1],train_data.shape[2])
    train_label_new.reshape(cnt)
    args.train_amount=cnt

    # Print training data size
    print('Training data size: ',train_data_new.shape)
    print('Training data label size:',train_label_new.shape)   
    # plt.imshow(train_data[0])
    # plt.show()

    return train_data_new, train_label_new

#%% Load the test data
def MNIST_DATASET_TEST(downloads, test_amount):
    # Load dataset
    testing_data = torchvision.datasets.MNIST(
              root = './mnist/',
              train = False,
        #       transform = torchvision.transforms.Compose([
        # torchvision.transforms.ToTensor(),
        # torchvision.transforms.Normalize((0.1307,), (0.3081,))]),
              download = downloads,
              transform=torchvision.transforms.ToTensor()
              )
    
    # Convert Testing data to numpy
    test_data_raw = testing_data.test_data.numpy()[:test_amount]
    test_label = testing_data.test_labels.numpy()[:test_amount]
    
    test_data = test_data_raw/255.0
    # test_data = test_data_raw

    # Print training data size
    print('test data size: ',test_data.shape)
    print('test data label size:',test_label.shape)   
    # plt.imshow(test_data[0])
    # plt.show()
    
    
    test_data_known=[]
    test_label_known=[]
    test_data_unknown=[]
    test_label_unknown=[]
    kcnt=0
    ucnt=0
    for i in range(len(test_label)):
        if test_label[i] in [0,1,2,3,4,5]:
            test_data_known.append(test_data[i])
            test_label_known.append(test_label[i])
            kcnt+=1
        else:
            test_data_unknown.append(test_data[i])
            test_label_unknown.append(test_label[i])
            ucnt+=1

    
    test_data_known=np.array(test_data_known)
    test_label_known=np.array(test_label_known)
    test_data_unknown=np.array(test_data_unknown)
    test_label_unknown=np.array(test_label_unknown)
    test_data_known.reshape(kcnt,test_data.shape[1],test_data.shape[2])
    test_label_known.reshape(kcnt)
    test_data_unknown.reshape(ucnt,test_data.shape[1],test_data.shape[2])
    test_label_unknown.reshape(ucnt)
    
    
    return test_data_known, test_label_known,test_data_unknown,test_label_unknown, test_data, test_label

def RunSVM(clf):
    clf.fit(training_features, train_label)
    
    # Test on Training data
    
    train_result = clf.predict(training_features)

    # print(len(train_result))
    precision = sum(train_result == train_label)/train_label.shape[0]
    print('Training precision: ', precision)

    #Test on test data known
    test_result_proba = clf.predict_proba(test_features_k)
    test_result=[]
    for i in range(len(test_result_proba)):
        res=0
        mx=test_result_proba[i][0]
        for j in range(len(test_result_proba[i])):
            if mx<test_result_proba[i][j]:
                res=j
                mx=test_result_proba[i][j]
        if mx<0.95:
            res=-1        
        test_result.append(res)

    accurate=0
    for i in range(len(test_result)):
        if test_label_k[i] in [6,7,8,9]:
            if test_result[i]==-1:
                accurate+=1
        else:
            if test_result[i]==test_label_k[i]:
                accurate+=1
    precision = accurate/test_label_k.shape[0]
    print('Test precision (known): ', precision)
    

        #Test on test data all
    test_result_proba = clf.predict_proba(test_features)
    test_result=[]
    for i in range(len(test_result_proba)):
        res=0
        mx=test_result_proba[i][0]
        for j in range(len(test_result_proba[i])):
            if mx<test_result_proba[i][j]:
                res=j
                mx=test_result_proba[i][j]
        if mx<0.95:
            res=-1        
        test_result.append(res)

    accurate=0
    for i in range(len(test_result)):
        if test_label[i] in [6,7,8,9]:
            if test_result[i]==-1:
                accurate+=1
        else:
            if test_result[i]==test_label[i]:
                accurate+=1
    precision = accurate/test_label.shape[0]
    print('Test precision (mixed): ', precision)

#%% Main function for MNIST dataset    
if __name__=='__main__':

    # Training Arguments Settings
    parser = argparse.ArgumentParser(description='Saak')
    parser.add_argument('--download_MNIST', default=True, metavar='DL',
                        help='Download MNIST (default: True)')
    parser.add_argument('--train_amount', type=int, default=60000,
                        help='Amount of training samples')
    parser.add_argument('--test_amount', type=int, default=10000,
                        help='Amount of testing samples')
    args = parser.parse_args()
    
    # Print Arguments
    print('\n----------Argument Values-----------')
    for name, value in vars(args).items():
        print('%s: %s' % (str(name), str(value)))
    print('------------------------------------\n')
    
    
    # Load Training Data & Testing Data
    train_data, train_label = MNIST_DATASET_TRAIN(args.download_MNIST, args.train_amount)
    test_data_k, test_label_k,test_data_u,test_label_u,test_data,test_label = MNIST_DATASET_TEST(args.download_MNIST, args.test_amount)

    training_features = train_data.reshape(args.train_amount,-1)
    test_features_k = test_data_k.reshape(len(test_label_k),-1)
    test_features_u = test_data_u.reshape(len(test_label_u),-1)
    test_features = test_data.reshape(len(test_label),-1)

    # Training SVM
    
    # clf = svm.SVC(C=1.0,kernel='rbf',tol=0.5,max_iter=1000,probability=True,verbose=True)
    print('------Training and testing SVM------')
    print("C:{}, kernel:{}, tol:{}".format(1.0,'rbf',0.5))
    clf = svm.SVC(C=1.0,kernel='rbf',tol=0.5,max_iter=1000,probability=True,verbose=False)
    RunSVM(clf)

    print('------Training and testing SVM------')
    print("C:{}, kernel:{}, tol:{}".format(0.5,'rbf',0.5))
    clf = svm.SVC(C=0.5,kernel='rbf',tol=0.5,max_iter=1000,probability=True,verbose=False)
    RunSVM(clf)

    print('------Training and testing SVM------')
    print("C:{}, kernel:{}, tol:{}".format(2.0,'rbf',0.5))
    clf = svm.SVC(C=2.0,kernel='rbf',tol=0.5,max_iter=1000,probability=True,verbose=False)
    RunSVM(clf)

    print('------Training and testing SVM------')
    print("C:{}, kernel:{}, tol:{}".format(1.0,'rbf',1))
    clf = svm.SVC(C=1.0,kernel='rbf',tol=1,max_iter=1000,probability=True,verbose=False)
    RunSVM(clf)
    
    
    #Show the confusion matrix
    # matrix = confusion_matrix(test_label, test_result)
