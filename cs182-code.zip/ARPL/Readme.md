# ARPL Alogorithm



## Datasets

mnist cifar10 cifar100



## Run

```
python osr.py --dataset <dataset> --loss Softmax
```

